<!DOCTYPE>
<html>
<head>
	<title>Tugas Akhir</title>
<link rel="stylesheet" type="text/css" href="css1/style1.css">
</head>
<body>
<?php include'header.php' ?>
<table id="main" cellspacing="0" border="0">
	<tr>
		<td id="grup" colspan="2">
			<table width="100%" height="100%" cellspacing="0" cellpadding="5">
				<tr>
					<td colspan="6" height="15%" style="padding-top:15px"><h2>Pakaian</h2></td>
				</tr>
				<tr>
					<td rowspan="2" width="20%" valign="top">
						<p><a href="#">Jawa</a>
						<p><a href="#">Sumatra</a>
						<p><a href="#">Bali</a>
						<p><a href="#">Madura</a>
						<p><a href="#">Papua</a>
					</td>
					<td width="20%"><a href="batik1.php" style="cursor:pointer;text-decoration:none">
						<table id="thumbnail" cellspacing="0" cellpadding="5">
							<tr>
								<td colspan="2"><div class="gambar_barang"><img src="img/batik1_1.jpg" width="100%"></td>
							</tr>
							<tr>
								<td colspan="2"><div class="nama_barang">Baju Couple Batik Mega Mendung</div></td>
							</tr>
							<tr>
								<td >Cirebon</td>
								<td><b>Rp 200.000</b></td>
							</tr>
						</table></a>
					</td>
					<td width="20%"><a href="batik2.php" style="cursor:pointer;text-decoration:none">
						<table id="thumbnail" cellspacing="0" cellpadding="5">
							<tr>
								<td colspan="2"><div class="gambar_barang"><img src="img/batik2_1.jpg" width="100%"></td>
							</tr>
							<tr>
								<td colspan="2"><div class="nama_barang">Kemeja Lengan Pendek Batik Pria Katun Halus</div></td>
							</tr>
							<tr>
								<td >Jakarta</td>
								<td><b>Rp 70.000</b></td>
							</tr>
						</table></a>
					</td>
					<td width="20%"><a href="batik3.php" style="cursor:pointer;text-decoration:none">
						<table id="thumbnail" cellspacing="0" cellpadding="5">
							<tr>
								<td colspan="2"><div class="gambar_barang"><img src="img/batik3_1.jpg" width="100%"></td>
							</tr>
							<tr>
								<td colspan="2"><div class="nama_barang">Callista V-Neck Tee Kaos Batik Polo Wanita</div></td>
							</tr>
							<tr>
								<td >Jakarta</td>
								<td><b>Rp 55.000</b></td>
							</tr>
						</table></a>
					</td>
					<td width="20%"><a href="sepatu.php" style="cursor:pointer;text-decoration:none">
						<table id="thumbnail" cellspacing="0" cellpadding="5">
							<tr>
								<td colspan="2"><div class="gambar_barang"><img src="img/sepatu1_1.jpg" width="100%"></td>
							</tr>
							<tr>
								<td colspan="2"><div class="nama_barang">Sepatu Batik Etnik Pink</div></td>
							</tr>
							<tr>
								<td >Bogor</td>
								<td><b>Rp 90.000</b></td>
							</tr>
						</table></a>
					</td>
				</tr>
				<tr>
					<td width="20%"><a href="rok.php" style="cursor:pointer;text-decoration:none">
						<table id="thumbnail" cellspacing="0" cellpadding="5">
							<tr>
								<td colspan="2"><div class="gambar_barang"><img src="img/rok_1.jpg" width="100%"></td>
							</tr>
							<tr>
								<td colspan="2"><div class="nama_barang">Rok Lilit Wanita Kain Batik</div></td>
							</tr>
							<tr>
								<td >Jakarta</td>
								<td><b>Rp 55.000</b></td>
							</tr>
						</table></a>
					</td>
					<td width="20%"><a href="barang.php" style="cursor:pointer;text-decoration:none">
					</td>
					<td width="20%"><a href="barang.php" style="cursor:pointer;text-decoration:none">
					</td>
					<td width="20%"><a href="barang.php" style="cursor:pointer;text-decoration:none">
					</td>
				</tr>
			</table>
		</td>
	</tr>
	<hr>
	<tr>
		<td id="footer" >
			<table width="200px" >
				<tr>
					<td>
						<img src="img/hp.png" height="120px">
					</td>
					<td valign="top">Download Aplikasinya di toko terdekat</td>
				</tr>
			</table></td>
		<td id="footer" valign="top">Follow Us<br><img src="img/sosmed.png" width="180px" height="50px"></td>
	</tr>
	<tr>
		<td id="copyright" colspan="2" align="center">Copyright &copy; 2017 Nama_Toko. All Rights Reserved</td>
	</tr>
</table>
</body>
</html>